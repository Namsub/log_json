import pandas as pd
import operator
from . import extract_layer_stat

def print_list(show_list):
	for val in show_list:
		print(val)

def eliminate_redundancy(ops_list):
	temp_list = []
	prev_ops = ops_list[0]
	temp_list.append(prev_ops)
	for cur_ops in ops_list:
		if prev_ops != cur_ops:
			temp_list.append(cur_ops)
			prev_ops = cur_ops

	sorted_temp_list = sorted(temp_list, key=operator.itemgetter(2))	
	for cur_ops in sorted_temp_list:
		print(cur_ops[2])
	
	del temp_list
	print("===========================================================")
	print("===========================================================")
	print("===========================================================")
	print("===========================================================")
	print("===========================================================")
	print("===========================================================")
	
	#'''
	ops_list_wo_redundancy = []
	prev_ops = sorted_temp_list[0]
	ops_list_wo_redundancy.append(prev_ops)
	for cur_ops in sorted_temp_list:
		if prev_ops[2] != cur_ops[2]:
			#print(prev_ops[2], prev_ops[3])
			ops_list_wo_redundancy.append(prev_ops)
			prev_ops = cur_ops
		else:
			prev_ops[3] += cur_ops[3]	# dur

	i =	1
	for cur_ops in ops_list_wo_redundancy:
		print(i, cur_ops[2], cur_ops[3])
		i += 1
	
	#exit()
	
	#'''
	#sorted_ops_list_wo_redundancy = sorted(ops_list_wo_redundancy, key=operator.itemgetter(0))

	#return sorted_ops_list_wo_redundancy
	return ops_list_wo_redundancy
	#return sorted_temp_list

def write_to_excel(ops_list, memory_with_ops_list, mode, filename):
	writer = pd.ExcelWriter(filename, engine = 'xlsxwriter')

	## metrics
	ops_list_wo_redundancy_1 = eliminate_redundancy(ops_list)
	print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
	print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
	print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
	print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
	print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
	print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
	print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
	print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
	i =	1
	for cur_ops in ops_list_wo_redundancy_1:
		print(i, cur_ops[2], cur_ops[3])
		i += 1
	columns_format = ['ts', 'op_type', 'op', 'total_dur(μs)', 'alloc_mem', 'req_mem', 'input_list', 'read_memory(MB)', 'write_memory(MB)', 'memory_usage(MB)', 'memory_bandwidth(GB/s)']
	#ops_values = pd.DataFrame(ops_list_wo_redundancy, columns=columns_format)
	ops_values = pd.DataFrame(ops_list_wo_redundancy_1, columns=columns_format)
	ops_values.to_excel(writer, sheet_name='metrics')

	'''
	## cpu/cpu_pool/cuda_host/gpu memory_usage
	memory_with_ops_list_wo_redundancy = eliminate_redundancy(memory_with_ops_list)
	columns_format = ['ts', 'cpu', 'cpu_pool', 'cuda_host', 'gpu', 'op']
	memory_values = pd.DataFrame(memory_with_ops_list_wo_redundancy, columns=columns_format)
	memory_values.to_excel(writer, sheet_name = 'memory_status_for_op')
	'''

	## for CNN
	if mode == 'vgg':
		layer_stats_list = extract_layer_stat.vgg(ops_list)
		columns_format = ['layer', 'duration(ms)', 'memory_usage(MB)']
		layer_values = pd.DataFrame(layer_stats_list, columns=columns_format)
		layer_values.to_excel(writer, sheet_name = 'layer granularity')
	
	elif mode == 'resnet':
		block_stats_list, unit_stats_list = extract_layer_stat.resnet(ops_list)			
		columns_format = ['layer', 'duration(ms)', 'Req_memory(MB)', 'allocated_memory(MB)']
		block_values = pd.DataFrame(block_stats_list, columns=columns_format)
		block_values.to_excel(writer, sheet_name = 'block granularity')
		unit_values = pd.DataFrame(unit_stats_list, columns=columns_format)
		unit_values.to_excel(writer, sheet_name = 'unit granularity')

	writer.save()

#def plot_memory_usage(memory_with_ops_list):
